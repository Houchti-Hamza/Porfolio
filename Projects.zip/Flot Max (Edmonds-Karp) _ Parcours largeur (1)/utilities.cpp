
#include <iostream>
#include <fstream>
#include <queue>
#include "utilities.h"

using namespace std;

void affichage(int* mat[], int n)
{
	for(int i = 0; i < n; i++){
		for(int j = 0; j < (n-1); j++)
			cout << mat[i][j] << "\t";
		cout << mat[i][n-1] << endl;		
	}
	cout << endl;
}

void chaineaugmentante(int* c[], int* f[], int n, int ch[],int s, int t)
{

    // Initialisation
    bool visite[n] = {false};
    int pred[n] = {-1};
    
    std::queue<int> file;
    visite[s] = true;
    file.push(s);
    
    // Parcours en largeur
    while(!file.empty()){
        int u = file.front();
        file.pop();
        for(int v = 0; v < n; v++){
            if(!visite[v] && c[u][v] > f[u][v]){
                visite[v] = true;
                pred[v] = u;
                file.push(v);
                if(v == t){
                    // Création de la chaine
                    int i = t;
                    int taille = 0;
                    while(pred[i] != -1){
                        ch[taille++] = i;
                        i = pred[i];
                    }
                    
                    ch[taille] = s;
                    
                    //Inversement de la chaine
                    for(int j = 0; j<=taille/2; j++){
                        int tmp = ch[j];
                        ch[j] = ch[taille-j];
                        ch[taille-j] = tmp;
                    }
                    // On sort de la fonction
                    return;
                }
            }
        }
    }
}

/****************************************************/

/****************************************************/
int increment(int* c[], int* f[], int n, int ch[], int s, int t)
{
  // Initialisation du flot
    int flow = 0;
    for(int i = 0; i < n; i++) {
        int prec = abs(ch[i]);
        if(ch[i] > -1) {
           if(c[prec][i] - f[prec][i] < flow && flow != 0) {
               flow = c[prec][i] - f[prec][i];
               
           } 
           else if (flow == 0) {
               flow = c[prec][i] - f[prec][i];
           }
        }
        else if(ch[i] < -1) {
            flow = c[prec][i] - f[prec][i];
        }
    }

    for(int i = 0; i < n; i++) {
            if(ch[i] > -1) {
                int prec = ch[i];
                f[prec][i] += flow;
            }
            else if(ch[i] < -1) {
                int prec = abs(ch[i]);
                f[prec][i] -= flow;
            }

        }
    cout << "flow " << flow << endl;
    return flow;
}


int fordfulkerson(int* c[], int* f[], int n, int s, int t, bool* S)
{
   
    
    int flotMax = 0;
    int ch[n];
    bool chaine;

    do {
        // Initialisation de la chaîne
        chaine = false;
        for (int i = 0; i < n; i++) {
            ch[i] = -1;
        }
        ch[s] = -2;

        // recherche de la chaîne augmentante
        queue<int> file;
        file.push(s);

        while (!file.empty()) {
            int u = file.front();
            file.pop();

            for (int v = 0; v < n; v++) {
                if (ch[v] == -1 && c[u][v] > f[u][v]) {
                    ch[v] = u;
                    if (v == t) {
                        chaine = true;
                        break;
                    }
                    file.push(v);
                }
            }
        }

        if (chaine) {
            // Calcul de l'augmentation de flot
            int increment = 1000;
            int v = t;
            while (v != s) {
                int u = ch[v];
                increment = min(increment, c[u][v] - f[u][v]);
                v = u;
            }

            // Mise à jour du flot et du flot maximal
            v = t;
            while (v != s) {
                int u = ch[v];
                f[u][v] += increment;
                f[v][u] -= increment;
                v = u;
            }

            flotMax += increment;
        }
    } while (chaine);

    for (int i = 0; i < n; i++) {
        S[i] = (ch[i] != -1);
    }

    return flotMax;
    
    
}

