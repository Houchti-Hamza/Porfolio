#include <iostream>
#include <cstdlib>
#include "utilities.h"

using namespace std;

int main() {
    int n = 6; // Nombre de noeuds
    int s = 0; // Noeud source
    int t = 5; // Noeud puits

    // Matrice de capacités du réseau
    int* c[n];
    for (int i = 0; i < n; i++) {
        c[i] = new int[n];
        for (int j = 0; j < n; j++) {
            c[i][j] = 0;
        }
    }
    c[0][1] = 90;
    c[0][2] = 11;
    c[1][2] = 10;
    c[1][3] = 33;
    c[2][1] = 23;
    c[2][4] = 74;
    c[3][2] = 65;
    c[3][5] = 18;
    c[4][3] = 19;
    c[4][5] = 111;

    // Matrice de flots du réseau
    int* f[n];
    for (int i = 0; i < n; i++) {
        f[i] = new int[n];
        for (int j = 0; j < n; j++) {
            f[i][j] = 0;
        }
    }

    // Calcul du flot maximum du réseau
    bool S[n];
    int maxflow = fordfulkerson(c, f, n, s, t, S);

    // Affichage des matrices de capacités et de flots
    cout << "Matrice de capacités :" << endl;
    affichage(c, n);
    cout << "Matrice de flots :" << endl;
    affichage(f, n);

    // Affichage du flot maximum
    cout << "Flot maximum : " << maxflow << endl;

    // Libération de la mémoire allouée pour les matrices
    for (int i = 0; i < n; i++) {
        delete[] c[i];
        delete[] f[i];
    }

    return 0;
}
