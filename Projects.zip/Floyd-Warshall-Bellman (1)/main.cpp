#include <iostream>
#include "utilities.h"

using namespace std;

int main() {
    // changer la matrice de test pour le problème du plus court chemin
    int A[7][20] = {
        {0,29,0,29,17,16,31},
        {29,0,31,32,38,8,36},
        {0,31,0,35,30,7,5},
        {29,32,35,0,19,10,25},
        {17,38,30,19,0,19,17},
        {16,8,7,10,19,0,31},
        {31,36,5,25,17,31,0},
    };
    
    // changer les distances pour le problème de l'optimisation des hotels
    int d[] = {0,24,33,77,130,137,173,179,322,391,400,417,424};
    int n = 12;
    int penalite = hotels(d, n);
    cout << "pénalité : " << penalite << endl;

    return 0;
}
