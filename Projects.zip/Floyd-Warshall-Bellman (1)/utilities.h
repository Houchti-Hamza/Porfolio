#ifndef _UTIL_H_
#define _UTIL_H_

const int N = 20;
void floydwarshall(int A[][N], int D[][N], int n);
int hotels(int d[], int n);

#endif
