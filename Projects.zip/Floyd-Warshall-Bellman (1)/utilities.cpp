#include <iostream>
#include <fstream>
#include "utilities.h"

using namespace std;

void floydwarshall(int A[][N], int D[][N], int n)
{
    int inf = 1000;
    for(int i = 0; i < n; i ++) {
        for(int j = 0; j < n; j++) {
            if(i == j) {
                D[i][j] = 0;
            }
            else if(A[i][j] >= 0) {
                D[i][j] = A[i][j];
            }
            else {
                D[i][j] = inf;
            }
        }
    }
    for(int k = 0; k < n; k++) {
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                if(D[i][j] > D[i][k] + D[k][j]) {
                    D[i][j] = D[i][k] + D[k][j];
                }
            }
        }
    }
    
}

int hotels(int d[], int n)
{
    const int MAX_INT = 10000000;
    int f[n+1] = {0};
    for (int i = n-1; i >= 0; i--) {

        int minPenalite = MAX_INT;
        for (int j = i+1; j <= n; j++) {
            int x = d[j] - d[i];
            int penalite = (200 - x)*(200 - x);
            int fullPenalite = penalite + f[j];
            minPenalite = min(minPenalite, fullPenalite);
        }
        f[i] = minPenalite;
    }
    return f[0];
}
