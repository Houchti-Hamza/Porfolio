<?php
    echo "<script type=\"text/javascript\" src=\"ceriCarApp/js/main.js\"></script>";
    echo "<br>";
    echo "<div class=\"w3-container\">";
        echo "<div class=\"w3-card-4\">";
            echo "<div class=\"w3-container w3-blue\">";
                echo "<h2>Voyages trouvés</h2>";
            echo "</div>";
            echo "<table class='w3-table w3-striped w3-border'>";
                echo "<tr>";
                    echo "<th> ID";
                    echo "<th> Nom du Conducteur";
                    echo "<th> Tarif";
                    echo "<th> Nb Places";
                    echo "<th> Heure départ";
                    echo "<th> Contraintes";
                    echo "<th>";
                echo "</tr>";
                foreach( $context->voyage1 as $voyage ){
                echo "<tr>";
                    echo "<td>". $voyage->id . "</td>";
                    echo "<td>". $voyage->conducteur->nom. "</td>";
                    echo "<td>". $voyage->tarif. "</td>";
                    echo "<td>". $voyage->nbplace. "</td>";
                    echo "<td>". $voyage->heuredepart. "</td>";
                    echo "<td>". $voyage->contraintes. "</td>";
                    echo "<td> <input data=\"$voyage->id\" align=\"center\" type=\"button\" action=\"?action=addResa\" method=\"get\" class=\"w3-btn w3-blue loadResa\" value=\"Réserver\"> </td>";
                echo "</tr>";
                }
            echo "</table>";
        echo "</div>";
    echo "</div>"; 
    echo "<br>";
    echo "<div class=\"w3-container w3-center w3-animate-bottom\">  ";
        echo 'Voyage bien trouvé';
    echo "</div>";
?>
