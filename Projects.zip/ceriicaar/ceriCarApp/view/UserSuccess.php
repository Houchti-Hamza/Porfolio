Voici l'utilisateur: <?php echo $context->mavariable ?> ! dingue non ? 
