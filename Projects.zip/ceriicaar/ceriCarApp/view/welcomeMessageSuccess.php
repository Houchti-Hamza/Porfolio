<?php 
if(isset($_SESSION['user_identifiant'])){

    echo "Vous êtes connecté avec le compte : ".$_SESSION['user_identifiant'];
}
?>

