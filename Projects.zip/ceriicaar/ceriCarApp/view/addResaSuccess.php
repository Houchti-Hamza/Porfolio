<script type="text/javascript" src="ceriCarApp/js/main.js"></script>
<div class="w3-container">
    <p>Réservation enregistrée  !</p>
   
</div>