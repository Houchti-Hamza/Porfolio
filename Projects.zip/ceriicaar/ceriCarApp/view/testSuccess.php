<?php

    echo "UTILISATEUR : ";
    echo "<br>";

    echo "ID : ". $context->utilisateur->id. "<br>";
    echo "Identifiant : ". $context->utilisateur->identifiant. "<br>";
    echo "pass : ". $context->utilisateur->pass. "<br>";
    echo "nom : ". $context->utilisateur->nom. "<br>";
    echo "prenom : ". $context->utilisateur->prenom. "<br>";
    echo "avatar : ". $context->utilisateur->avatar. "<br>";
    echo "<br>";

    echo "TRAJET : ";
    echo "<br>";

    echo "id : ". $context->trajet->id. "<br>";
    echo "depart : ". $context->trajet->depart. "<br>";
    echo "arrivee : ". $context->trajet->arrivee. "<br>";
    echo "distance : ". $context->trajet->distance. "<br>";
    echo "<br>";

    echo "VOYAGE : ";
    echo "<br>";
    foreach( $context->voyage1 as $voyage ){

        echo "id : ". $voyage->id. "<br>";
        echo "nom du conducteur : ". $voyage->conducteur->nom. "<br>";
        echo "départ trajet : ". $voyage->trajet->depart. "<br>";
        echo "tarif : ". $voyage->tarif. "<br>";
        echo "nbplace : ". $voyage->nbplace. "<br>";
        echo "heure de depart : ". $voyage->heuredepart. "<br>";
        echo "contraintes : ". $voyage->contraintes. "<br>";
        echo "<br>";

    }
    echo "<br>";

    echo "RESERVATION : ";
    echo "<br>";

    foreach($context->reservation1 as $reservation){
        echo "id : ". $reservation->id. "<br>";
        echo "tarif du voyage : ". $reservation->voyage->tarif. "<br>";
        echo "nom de l'utilisateur : ". $reservation->voyageur->nom. "<br>";
        echo "<br>";
    }
    echo "<br>";

    echo "UTILISATEUR BY ID : ";
    echo "<br>";

    echo "ID : ". $context->utilisateurbyid->id. "<br>";
    echo "Identifiant : ". $context->utilisateurbyid->identifiant. "<br>";
    echo "pass : ". $context->utilisateurbyid->pass. "<br>";
    echo "nom : ". $context->utilisateurbyid->nom. "<br>";
    echo "prenom : ". $context->utilisateurbyid->prenom. "<br>";
    echo "avatar : ". $context->utilisateurbyid->avatar. "<br>";

    echo "<br>";

?>