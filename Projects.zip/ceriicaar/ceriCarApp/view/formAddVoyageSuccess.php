<script type="text/javascript" src="ceriCarApp/js/main.js"></script>
<div class="w3-container">
  <div class="w3-card-4">
    <div class="w3-container w3-orange">
      <h2>Proposer un voyage</h2>
    </div>

    <form class="w3-container formulaire" onsubmit="return false" method="post" action="?action=addVoyage">
      <p>
      <label for="depart">Depart</label>
      <input class="w3-input" type="text" id="depart" name="depart" required>
      <p>
      <label for="arrivee">Arrivee</label>
      <input class="w3-input" type="text" id="arrivee" name="arrivee" required>
        <br>
        <label for="arrivee">Heure de départ</label>
      <input class="w3-input" type="text" id="heure" name="heure" required>
        <br>
        <label for="arrivee">Nombre de place</label>
      <input class="w3-input" type="text" id="nbplace" name="nbplace" required>
        <br>
        <label for="arrivee">Tarif</label>
      <input class="w3-input" type="text" id="tarif" name="tarif" required>
        <br>
        <label for="arrivee">Contraites</label>
      <input class="w3-input" type="text" id="contraintes" name="contraintes" required>
        <br>
      <input class="w3-button w3-round w3-orange" type="submit" value="Proposer ce voyage">

    </form>
  </div>
</div>
