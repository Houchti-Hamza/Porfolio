<script type="text/javascript" src="ceriCarApp/js/main.js"></script>
<div class="w3-container">
  <div class="w3-card-4">
    <div class="w3-container w3-blue">
      <h2>Log In</h2>
    </div>

    <form class="w3-container formulaire" onsubmit="return false" method="post" action="?action=getUserByLoginAndPass" id="loadUser">
      <p>
      <label for="depart">Login</label>
      <input class="w3-input" type="text" id="login" name="login" required>
      <p>
      <label for="arrivee">Password</label>
      <input class="w3-input" type="password" id="psw" name="psw" required>
        <br>
      <input class="w3-button w3-round w3-blue connection" type="submit" value="Se connecter">

    </form>
  </div>
</div>
