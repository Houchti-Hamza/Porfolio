<script type="text/javascript" src="ceriCarApp/js/main.js"></script>
<div class="w3-container">
    <p>L'inscription n'a pas fonctionné...</p>
   
</div>