<script type="text/javascript" src="ceriCarApp/js/main.js"></script>
<div class="w3-container">
    <p>Re-Bonjour <?php echo $_SESSION['user_identifiant'] ?> ! </p>
    
</div>